-- combined_SAKA.py

must make variable files which is a list with all the file names to go through: 
    files = ["comment_scrapes/changemyview_comment_scrape.json", "comment_scrapes/Conservative_comment_scrape.json", "comment_scrapes/conspiracy_comment_scrape.json", "comment_scrapes/democrats_comment_scrape.json", "comment_scrapes/PoliticalDiscussion_comment_scrape.json", "comment_scrapes/politics_comment_scrape.json", "comment_scrapes/TrueReddit_comment_scrape.json"]

this is used as input parameter for SAKA function which returns a directory with sentiment and keyword analysis done on each subreddit

-- postPartitioning,py

must make variable files which is a list with all the file names to go through: 
	    files = ["COMBINED_analysis/changemyview_analysis.json", "COMBINED_analysis/Conservative_analysis.json", "COMBINED_analysis/conspiracy_analysis.json", "COMBINED_analysis/democrats_analysis.json", "COMBINED_analysis/PoliticalDiscussion_analysis.json", "COMBINED_analysis/politics_analysis.json", "COMBINED_analysis/TrueReddit_analysis.json"]

this is used as input parameter for the sentiment_sorting function which returns a directory called "data_analysis" which has the positive, negative, and neutral posts for each subreddit. 

-- global_averageSentiment.py

- Has 6 functions, 3 which print txt files of the average sentiments, post keywords and comment keywords
- the other 3 functions provide the structure to print these txt files
- must call structure functions before you call the printing functions

ie: 
    getCommentKeywordStructure()
    printTop20CommentKW()
    
    getPostKeywordStructure()
    printTop20PostKW()
    
    x = getAverageStructure()
    computeAverages(x)
    NOTE: the function getAverageStructure() must be bound to a variable and computeAverages() must take in that variable
 

